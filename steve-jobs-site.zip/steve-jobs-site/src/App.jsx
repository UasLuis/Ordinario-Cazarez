import { Routes, Route } from 'react-router-dom'
import Navbar from './components/Navbar.jsx'
import Home from './pages/Home.jsx'
import Biography from './pages/Biography.jsx'
import Legacy from './pages/Legacy.jsx'

export default function App() {
  return (
    <>
      <Navbar />
      <main className="container">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/biografia" element={<Biography />} />
          <Route path="/legado" element={<Legacy />} />
        </Routes>
      </main>
      <footer>
        Hecho con React y React Router · Contenido educativo sobre Steve Jobs
      </footer>
    </>
  )
}
