
export default function Legacy() {
  return (
    <article className="card">
      <h2>Legado</h2>
      <ul>
        <li><strong>Diseño centrado en el usuario:</strong> Prioridad a la simplicidad, la estética y la experiencia integral.</li>
        <li><strong>Integración hardware-software:</strong> Ecosistemas cohesionados que facilitan el uso y elevan la calidad.</li>
        <li><strong>Innovación en múltiples industrias:</strong> Computación personal, música digital, telefonía móvil y animación.</li>
        <li><strong>Presentaciones y narrativa:</strong> Capacidad para comunicar visiones y convertir productos en historias inspiradoras.</li>
      </ul>
      <p>
        La filosofía de Jobs sigue influenciando cómo se conciben productos tecnológicos hoy: foco, excelencia y atención al detalle.
      </p>
    </article>
  )
}
