
export default function Biography() {
  return (
    <article className="card">
      <h2>Biografía</h2>
      <p>
        Steve Jobs (1955–2011) fue un empresario y visionario tecnológico estadounidense. Adoptado al nacer, creció en California y desde joven mostró interés por la electrónica.
      </p>
      <p>
        En 1976 cofundó Apple Computer junto a Steve Wozniak y Ronald Wayne. El Apple II y, más tarde, el Macintosh (1984) popularizaron las computadoras personales con interfaces gráficas.
      </p>
      <p>
        En 1985, tras diferencias internas, Jobs dejó Apple. Fundó NeXT, enfocada en estaciones de trabajo de alto rendimiento, y adquirió The Graphics Group, que se convirtió en Pixar Animation Studios.
      </p>
      <p>
        Apple adquirió NeXT en 1996, lo que propició el regreso de Jobs como CEO interino y luego permanente. Con una estrategia clara y un enfoque en productos integrados, lideró el lanzamiento de iMac, iTunes, iPod, iPhone y iPad.
      </p>
      <p>
        En 2006, Disney compró Pixar, consolidando el impacto de Jobs también en la industria del entretenimiento. Jobs falleció el 5 de octubre de 2011, dejando una huella indeleble en la tecnología y el diseño.
      </p>
    </article>
  )
}
