
export default function Home() {
  return (
    <section>
      <div className="hero">
        <h1>Steve Jobs</h1>
        <p>Visionario, innovador y cofundador de Apple Inc.</p>
      </div>
      <div className="grid">
        <div className="card">
          <h3>Biografía</h3>
          <p>
            Nacido el 24 de febrero de 1955 en San Francisco, Steve Jobs cofundó Apple en 1976 junto con Steve Wozniak y Ronald Wayne.
            Tras dejar Apple en 1985, fundó NeXT y adquirió Pixar, compañía de animación que se convertiría en un referente de la industria.
          </p>
        </div>
        <div className="card">
          <h3>Apple Regresa</h3>
          <p>
            En 1997 volvió a Apple como CEO, liderando la creación de productos emblemáticos como iMac (1998), iPod (2001), iPhone (2007) e iPad (2010).
          </p>
        </div>
        <div className="card">
          <h3>Legado</h3>
          <p>
            Su enfoque en el diseño, la simplicidad y la experiencia de usuario transformó múltiples industrias. Falleció el 5 de octubre de 2011, pero su influencia perdura.
          </p>
        </div>
      </div>
    </section>
  )
}
