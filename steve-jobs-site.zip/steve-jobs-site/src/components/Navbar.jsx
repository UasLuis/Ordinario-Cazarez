
import { NavLink } from 'react-router-dom'

export default function Navbar() {
  return (
    <nav>
      <div className="navbar container">
        <NavLink to="/" className="brand">Steve Jobs</NavLink>
        <div style={{display:'flex', gap:'0.5rem'}}>
          <NavLink to="/" end>Inicio</NavLink>
          <NavLink to="/biografia">Biografía</NavLink>
          <NavLink to="/legado">Legado</NavLink>
        </div>
      </div>
    </nav>
  )
}
