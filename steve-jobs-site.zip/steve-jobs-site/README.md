
# Sitio de React: Steve Jobs

Este proyecto es un sitio web sencillo en **React** con **React Router** para explorar la vida y el legado de **Steve Jobs**.

## 🚀 Cómo ejecutar

1. Asegúrate de tener **Node.js** (>= 18) y **npm** instalados.
2. En una terminal, ve a la carpeta del proyecto y ejecuta:

```bash
npm install
npm run dev
```

3. Abre el enlace que te dará Vite (por ejemplo `http://localhost:5173`).

## 🧱 Estructura

```
steve-jobs-site/
├── index.html
├── package.json
├── README.md
├── src/
│   ├── App.jsx
│   ├── main.jsx
│   ├── styles.css
│   ├── components/
│   │   └── Navbar.jsx
│   └── pages/
│       ├── Home.jsx
│       ├── Biography.jsx
│       └── Legacy.jsx
└── public/
    └── favicon.svg
```

## 🧭 Rutas
- `/` — Inicio
- `/biografia` — Biografía
- `/legado` — Legado

## 📄 Licencia
Uso educativo.
